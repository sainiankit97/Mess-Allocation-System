from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile, UpdateDetails

class UserRegisterForm(UserCreationForm):
	email = forms.EmailField()
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']

class UserUpdateForm(forms.ModelForm):
	email = forms.EmailField()
	
	class Meta:
		model = User
		fields = ['username', 'email']


class ProfileUpdateForm(forms.ModelForm):
	class Meta:
		model = Profile
		fields = ['image']

class UpdateDetailsForm(forms.Form):
	GENDER = [
		('MALE','MALE'),
		('FEMALE','FEMALE')
	]
	COURSE = [
		('B.Tech','B.Tech'),
		('M.Tech','M.Tech'),
		('MCA','MCA'),
		('M.Sc','M.Sc'),
		('MBA','MBA')
	]
	DEPARTMENT = [
		('Computer Science And Engineering','Computer Science And Engineering'),
		('Mathematical And Computational Sciences','Mathematical And Computational Sciences'),
		('Information Technology','Information Technology'),
        ('Chemical Engineering','Chemical Engineering'),
        ('Civil Engineering','Civil Engineering'),
        ('Mechanical Engineering','Mechanical Engineering'),
        ('School Of Management', 'School Of Management')
	]
	HOSTEL = [
		('1st Block','1st Block'),
        ('2nd Block','2nd Block'),
        ('3rd Block','3rd Block'),
        ('4th Block','4th Block'),
        ('5th Block','5th Block'),
        ('7th Block','7th Block'),
        ('8th Block','8th Block'),
        ('Mega Block','Mega Block'),
        ('PG Block','PG Block')
	]
	stu_gender= forms.CharField(label = 'Select Gender',widget=forms.Select(
			choices = GENDER,
			attrs = {
				'text-color': 'Blue'
			}
		))
	stu_course= forms.CharField(label = 'Select Course',widget=forms.Select(
			choices = COURSE,
			attrs = {
				'text-color': 'white'
			}
		))
	stu_dept= forms.CharField(label = 'Select Department BLock',widget=forms.Select(
			choices = DEPARTMENT,
			attrs = {
				'text-color': 'white'
			}
		))
	stu_hostel_block= forms.CharField(label = 'Select Hostel',widget=forms.Select(
			choices = HOSTEL,
			attrs = {
				'text-color': 'white',
			}
		))
	stu_room_no= forms.CharField(widget=forms.TextInput(
			attrs={
				'class': 'form-control',
				'placeholder': 'Enter the room number',
			}
		))
	stu_contact= forms.CharField(widget=forms.TextInput(
			attrs={
				'class': 'form-control',
				'placeholder': 'Enter mobile number',
			}
		)) 
	stu_mess_roll_no= forms.CharField(widget=forms.TextInput(
			attrs={
				'class': 'form-control',
				'placeholder': 'Enter mess roll number',
			}
		))