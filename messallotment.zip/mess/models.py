from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

class MessModel(models.Model):
	mess_id = models.CharField(max_length=20, primary_key=True)
	mess_name = models.CharField(max_length=30, null=False)
	mess_type = models.CharField(max_length=10, default='VEG')
	mess_boys = models.CharField(max_length=10, default='MALE')
	mess_capacity = models.IntegerField()
	remaining_seats = models.IntegerField()
	def __str__(self):
		return self.mess_id

class ContactModel(models.Model):
	student_name = models.CharField(max_length=20)
	student_email = models.CharField(max_length=30)
	Feedback = models.CharField(max_length=200)
	def __str__(self):
		return f'{self.student_name}feedback'

class FeeDetailsModel(models.Model):
	stu_reg_no = models.ForeignKey(User, on_delete= models.CASCADE)
	transaction_id = models.CharField(max_length=100)
	fee_status = models.BooleanField(default= False)

	def __str__(self):
		return f'{self.stu_reg_no}fees'

class MessAllotModel(models.Model):
	allot_reg_no = models.ForeignKey(User , on_delete= models.CASCADE)
	allot_mess_id = models.ForeignKey(MessModel , on_delete=models.CASCADE)
	allot_mess = models.BooleanField(default = False)
	allot_date = models.DateTimeField(default= timezone.now)

	def __str__(self):
		return f'{self.allot_reg_no}alloted'